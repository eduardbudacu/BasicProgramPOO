// BasicProgram.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Program.h"

int main()
{
	Program *prog = new Program();
	prog->run();
}
